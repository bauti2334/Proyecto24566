/**
 * Simulador ESP32 — ProyectoNodo
 * Simula 10 sensores enviando datos reales al backend
 * Uso: node simulador.js
 */
const http  = require('http');
const dgram = require('dgram');

const HOST  = 'localhost';
const PORT  = 3000;
const TOKEN = 'sv-iot-token-2024';
const MS    = 8000;

const SENSORES = [
  { mac:'AA:BB:CC:01:01:01', nombre:'temp-norte-01',   tipo:'Temperatura', valor:22.0,  unidad:'°C',  ip:'192.168.1.101', rssi:-45 },
  { mac:'AA:BB:CC:01:02:01', nombre:'hum-norte-01',    tipo:'Humedad',     valor:58.0,  unidad:'%',   ip:'192.168.1.102', rssi:-50 },
  { mac:'AA:BB:CC:02:01:01', nombre:'temp-sur-01',     tipo:'Temperatura', valor:26.5,  unidad:'°C',  ip:'192.168.1.111', rssi:-55 },
  { mac:'AA:BB:CC:02:02:01', nombre:'hum-sur-01',      tipo:'Humedad',     valor:72.0,  unidad:'%',   ip:'192.168.1.112', rssi:-60 },
  { mac:'AA:BB:CC:03:01:01', nombre:'temp-oficina',    tipo:'Temperatura', valor:21.0,  unidad:'°C',  ip:'192.168.1.121', rssi:-35 },
  { mac:'AA:BB:CC:03:02:01', nombre:'co2-oficina',     tipo:'CO2',         valor:520.0, unidad:'ppm', ip:'192.168.1.122', rssi:-40 },
  { mac:'AA:BB:CC:04:01:01', nombre:'temp-deposito',   tipo:'Temperatura', valor:18.0,  unidad:'°C',  ip:'192.168.1.131', rssi:-65 },
  { mac:'AA:BB:CC:04:02:01', nombre:'pres-caldera',    tipo:'Presión',     valor:1013,  unidad:'hPa', ip:'192.168.1.132', rssi:-58 },
  { mac:'AA:BB:CC:01:03:01', nombre:'luz-planta-norte',tipo:'Luz',         valor:3200,  unidad:'lux', ip:'192.168.1.103', rssi:-70 },
  { mac:'AA:BB:CC:02:03:01', nombre:'co2-sur',         tipo:'CO2',         valor:450,   unidad:'ppm', ip:'192.168.1.113', rssi:-52 },
];

const VAR = {
  Temperatura: { d:0.4, mn:-10, mx:55 },
  Humedad:     { d:1.0, mn:0,   mx:100 },
  CO2:         { d:20,  mn:300, mx:4000 },
  Presión:     { d:0.5, mn:960, mx:1040 },
  Luz:         { d:150, mn:0,   mx:10000 },
};

function variar(s) {
  const v = VAR[s.tipo] || { d:1, mn:0, mx:100 };
  s.valor = +Math.max(v.mn, Math.min(v.mx, s.valor + (Math.random()-.5)*v.d*2)).toFixed(1);
  // pico ocasional (4%)
  if (Math.random() < 0.04) {
    s.valor = +(s.valor * (s.tipo==='Temperatura' ? 1.4 : 1.3)).toFixed(1);
    console.log(`  ⚡ PICO ${s.nombre}: ${s.valor} ${s.unidad}`);
  }
  return s.valor;
}

function post(body) {
  return new Promise(resolve => {
    const d = JSON.stringify(body);
    const r = http.request({
      hostname: HOST, port: PORT,
      path: '/api/sensores/datos', method: 'POST',
      headers: { 'Content-Type':'application/json', 'Content-Length':Buffer.byteLength(d), 'Authorization':'Bearer '+TOKEN },
    }, res => { res.on('data',()=>{}); res.on('end', () => resolve(res.statusCode)); });
    r.on('error', () => resolve(0));
    r.write(d); r.end();
  });
}

const udp = dgram.createSocket('udp4');
function broadcast(s) {
  const m = JSON.stringify({ evento:'sv-iot-announce', mac:s.mac, nombre:s.nombre, tipo:s.tipo, ip:s.ip });
  udp.setBroadcast(true);
  udp.send(m, 5050, '255.255.255.255', ()=>{});
}

async function tick() {
  console.log(`\n[${new Date().toLocaleTimeString('es-AR')}] Enviando lecturas...`);
  await Promise.all(SENSORES.map(async s => {
    broadcast(s);
    const v   = variar(s);
    const cod = await post({ mac:s.mac, nombre:s.nombre, tipo:s.tipo, valor:v, unidad:s.unidad, ip:s.ip, rssi:s.rssi });
    console.log(`  ${cod===200||cod===201?'✓':'✗'} ${s.nombre.padEnd(22)} ${String(v).padStart(8)} ${s.unidad}`);
  }));
}

console.log('╔══════════════════════════════════════╗');
console.log('║  Simulador ESP32 — ProyectoNodo      ║');
console.log('╚══════════════════════════════════════╝');
console.log(`Backend: http://${HOST}:${PORT}`);
console.log(`Sensores: ${SENSORES.length} | Intervalo: ${MS/1000}s`);
console.log('Ctrl+C para detener\n');

tick();
setInterval(tick, MS);
