/**
 * Inicializar Firebase — ProyectoNodo
 * Correr UNA SOLA VEZ: node init-db.js
 */
require('dotenv').config();
const admin = require('firebase-admin');
const sa    = require('./serviceAccountKey.json');

admin.initializeApp({
  credential:  admin.credential.cert(sa),
  databaseURL: process.env.FIREBASE_DB_URL,
});
const db = admin.database();

async function init() {
  console.log('🔧 Inicializando base de datos en Firebase...\n');

  await db.ref('sectores').set({
    s1: { id:'s1', nombre:'Planta Norte', descripcion:'Zona de producción norte', creadoEn: Date.now() },
    s2: { id:'s2', nombre:'Planta Sur',   descripcion:'Zona de producción sur',   creadoEn: Date.now() },
    s3: { id:'s3', nombre:'Oficinas',     descripcion:'Área administrativa',      creadoEn: Date.now() },
    s4: { id:'s4', nombre:'Almacén',      descripcion:'Depósito principal',       creadoEn: Date.now() },
  });
  console.log('✓ Sectores creados');

  await db.ref('usuarios').set({
    admin:  { id:'admin',  nombre:'Administrador', username:'admin',  pass:'1234',   rol:'admin',      email:'admin@sv.com',  estado:'activo', sector:'s1', creadoEn: Date.now() },
    carlos: { id:'carlos', nombre:'Carlos Méndez', username:'carlos', pass:'mod123', rol:'moderador',  email:'carlos@sv.com', estado:'activo', sector:'s1', creadoEn: Date.now() },
    sofia:  { id:'sofia',  nombre:'Sofía Ruiz',    username:'sofia',  pass:'mod456', rol:'moderador',  email:'sofia@sv.com',  estado:'activo', sector:'s2', creadoEn: Date.now() },
    juan:   { id:'juan',   nombre:'Juan Torres',   username:'juan',   pass:'cli123', rol:'cliente',    email:'juan@sv.com',   estado:'activo', sector:'s1', creadoEn: Date.now() },
  });
  console.log('✓ Usuarios creados');

  await db.ref('umbrales').set({
    tmin:10, tmax:35, tcrit:40,
    hmin:30, hmax:80, hcrit:90,
    co2ok:600, co2wa:1000, co2cr:2000,
    batlo:20, batcr:10,
    actualizadoEn: Date.now(),
  });
  console.log('✓ Umbrales configurados');

  await db.ref('alertas').push({
    tipo:'in', titulo:'Sistema iniciado',
    msg:'Bienvenido a Soluciones Victoria IoT. Todo listo.',
    icono:'ri-information-line', ts: Date.now(),
  });
  console.log('✓ Alerta de bienvenida creada\n');

  console.log('═══════════════════════════════════');
  console.log('  Base de datos lista en Firebase  ');
  console.log('═══════════════════════════════════');
  console.log('  admin  / 1234    → Administrador');
  console.log('  carlos / mod123  → Moderador');
  console.log('  sofia  / mod456  → Moderador');
  console.log('  juan   / cli123  → Cliente');
  console.log('\n  Ahora corré: node server.js\n');
  process.exit(0);
}

init().catch(e => { console.error('Error:', e.message); process.exit(1); });
