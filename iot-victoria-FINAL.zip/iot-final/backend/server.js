/**
 * Soluciones Victoria — Backend IoT
 * Node.js + Express + Firebase Realtime Database
 * Proyecto: proyectonodo
 */

require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const admin   = require('firebase-admin');
const dgram   = require('dgram');
const path    = require('path');

// ─── FIREBASE ────────────────────────────────
const serviceAccount = require('./serviceAccountKey.json');
admin.initializeApp({
  credential:  admin.credential.cert(serviceAccount),
  databaseURL: process.env.FIREBASE_DB_URL,
});
const db = admin.database();
console.log('✓ Firebase conectado:', process.env.FIREBASE_DB_URL);

// ─── HELPERS DB ──────────────────────────────
const dbGet    = (p)    => db.ref(p).once('value').then(s => s.val());
const dbSet    = (p, d) => db.ref(p).set(d);
const dbUpdate = (p, d) => db.ref(p).update(d);
const dbPush   = (p, d) => db.ref(p).push(d);
const dbRemove = (p)    => db.ref(p).remove();

// ─── EXPRESS ─────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// ─── AUTH MIDDLEWARE (para ESP32) ─────────────
const API_TOKEN = process.env.API_TOKEN || 'sv-iot-token-2024';
function authDevice(req, res, next) {
  const auth = req.headers['authorization'] || '';
  if (auth.replace('Bearer ', '') !== API_TOKEN) {
    return res.status(401).json({ error: 'Token inválido' });
  }
  next();
}

// ════════════════════════════════════════════
//  RUTAS: SENSORES
// ════════════════════════════════════════════

// Recibir lectura del ESP32
app.post('/api/sensores/datos', authDevice, async (req, res) => {
  try {
    const { mac, nombre, tipo, valor, unidad, ip, rssi, sector } = req.body;
    if (!mac || valor === undefined) return res.status(400).json({ error: 'Faltan mac o valor' });

    const sensorId = 'esp_' + mac.replace(/[:.]/g, '').toLowerCase();
    const ahora    = Date.now();
    const existing = await dbGet(`sensores/${sensorId}`);

    await dbUpdate(`sensores/${sensorId}`, {
      id:            sensorId,
      mac,
      nombre:        nombre || sensorId,
      tipo:          tipo   || 'Desconocido',
      valor,
      unidad:        unidad || '',
      ip:            ip     || '',
      rssi:          rssi   || null,
      sector:        sector || existing?.sector || '',
      registrado:    existing?.registrado ?? false,
      estado:        'online',
      ultimaLectura: ahora,
      actualizadoEn: ahora,
      ...(existing ? {} : { creadoEn: ahora }),
    });

    // Historial (últimas 60 lecturas)
    await dbPush(`historial/${sensorId}`, { valor, ts: ahora });

    // Chequear umbrales
    const umbrales = await dbGet('umbrales') || {};
    await checkThresholds(sensorId, nombre || sensorId, tipo, valor, unidad, umbrales);

    console.log(`[${new Date().toLocaleTimeString()}] ${nombre} → ${valor} ${unidad}  (${ip})`);
    res.json({ ok: true, sensorId, nuevo: !existing });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

// Listar sensores
app.get('/api/sensores', async (req, res) => {
  try {
    const data  = await dbGet('sensores') || {};
    const ahora = Date.now();
    const list  = Object.values(data).map(s => ({
      ...s,
      estado: (ahora - (s.ultimaLectura || 0)) < 35000 ? 'online' : 'offline',
    }));
    res.json(list);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Un sensor
app.get('/api/sensores/:id', async (req, res) => {
  const s = await dbGet(`sensores/${req.params.id}`);
  if (!s) return res.status(404).json({ error: 'No encontrado' });
  res.json(s);
});

// Actualizar (registrar, asignar sector, etc.)
app.put('/api/sensores/:id', async (req, res) => {
  try {
    await dbUpdate(`sensores/${req.params.id}`, { ...req.body, actualizadoEn: Date.now() });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Eliminar
app.delete('/api/sensores/:id', async (req, res) => {
  try { await dbRemove(`sensores/${req.params.id}`); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// Historial
app.get('/api/historial/:id', async (req, res) => {
  try {
    const data = await dbGet(`historial/${req.params.id}`) || {};
    const arr  = Object.values(data).sort((a, b) => a.ts - b.ts).slice(-60);
    res.json(arr);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ════════════════════════════════════════════
//  RUTAS: SECTORES
// ════════════════════════════════════════════
app.get('/api/sectores', async (req, res) => {
  const data = await dbGet('sectores') || {};
  res.json(Object.values(data));
});

app.post('/api/sectores', async (req, res) => {
  const { nombre, descripcion } = req.body;
  if (!nombre) return res.status(400).json({ error: 'nombre requerido' });
  const id = 's_' + Date.now();
  await dbSet(`sectores/${id}`, { id, nombre, descripcion: descripcion || '', creadoEn: Date.now() });
  res.json({ ok: true, id });
});

app.delete('/api/sectores/:id', async (req, res) => {
  await dbRemove(`sectores/${req.params.id}`);
  res.json({ ok: true });
});

// ════════════════════════════════════════════
//  RUTAS: USUARIOS + AUTH
// ════════════════════════════════════════════
app.post('/api/auth/login', async (req, res) => {
  const { username, pass } = req.body;
  const user = await dbGet(`usuarios/${username}`);
  if (!user || user.pass !== pass || user.estado !== 'activo') {
    return res.status(401).json({ error: 'Credenciales incorrectas' });
  }
  const { pass: _, ...safe } = user;
  res.json({ ok: true, user: safe });
});

app.get('/api/usuarios', async (req, res) => {
  const data = await dbGet('usuarios') || {};
  res.json(Object.values(data).map(({ pass, ...u }) => u));
});

app.post('/api/usuarios', async (req, res) => {
  const { nombre, username, email, pass, rol, sector } = req.body;
  if (!username || !pass) return res.status(400).json({ error: 'username y pass requeridos' });
  const ex = await dbGet(`usuarios/${username}`);
  if (ex) return res.status(409).json({ error: 'Usuario ya existe' });
  await dbSet(`usuarios/${username}`, {
    id: username, nombre, username, email, pass,
    rol: rol || 'cliente', sector: sector || '',
    estado: 'activo', creadoEn: Date.now(),
  });
  res.json({ ok: true });
});

app.put('/api/usuarios/:id', async (req, res) => {
  const { pass, ...data } = req.body;
  const update = { ...data, actualizadoEn: Date.now() };
  if (pass) update.pass = pass;
  await dbUpdate(`usuarios/${req.params.id}`, update);
  res.json({ ok: true });
});

app.delete('/api/usuarios/:id', async (req, res) => {
  await dbRemove(`usuarios/${req.params.id}`);
  res.json({ ok: true });
});

// ════════════════════════════════════════════
//  RUTAS: UMBRALES
// ════════════════════════════════════════════
app.get('/api/umbrales', async (req, res) => {
  const data = await dbGet('umbrales') || {
    tmin:10, tmax:35, tcrit:40, hmin:30, hmax:80, hcrit:90,
    co2ok:600, co2wa:1000, co2cr:2000, batlo:20, batcr:10,
  };
  res.json(data);
});

app.put('/api/umbrales', async (req, res) => {
  await dbUpdate('umbrales', { ...req.body, actualizadoEn: Date.now() });
  res.json({ ok: true });
});

// ════════════════════════════════════════════
//  RUTAS: ALERTAS
// ════════════════════════════════════════════
app.get('/api/alertas', async (req, res) => {
  const data = await dbGet('alertas') || {};
  const arr  = Object.entries(data)
    .map(([k, v]) => ({ key: k, ...v }))
    .sort((a, b) => b.ts - a.ts)
    .slice(0, 50);
  res.json(arr);
});

app.delete('/api/alertas/:key', async (req, res) => {
  await dbRemove(`alertas/${req.params.key}`);
  res.json({ ok: true });
});

// ════════════════════════════════════════════
//  RUTAS: DISCOVERY (scan LAN desde frontend)
// ════════════════════════════════════════════
app.post('/api/discovery/scan', async (req, res) => {
  const { subnet } = req.body;
  if (!subnet) return res.status(400).json({ error: 'subnet requerida' });

  const found    = [];
  const promises = [];
  for (let i = 1; i <= 254; i++) {
    const ip = `${subnet}.${i}`;
    promises.push(
      fetch(`http://${ip}/info`, { signal: AbortSignal.timeout(400) })
        .then(r => r.json())
        .then(d => { if (d?.mac) found.push({ ...d, ip }); })
        .catch(() => null)
    );
  }
  await Promise.all(promises);
  res.json(found);
});

// ════════════════════════════════════════════
//  LÓGICA: CHECK UMBRALES → ALERTAS
// ════════════════════════════════════════════
async function checkThresholds(sensorId, nombre, tipo, valor, unidad, u) {
  let alerta = null;
  if (tipo === 'Temperatura') {
    if      (valor > (u.tcrit || 40)) alerta = { tipo:'cr', titulo:'Temperatura crítica',  msg:`${nombre}: ${valor}${unidad} supera límite crítico` };
    else if (valor > (u.tmax  || 35)) alerta = { tipo:'wa', titulo:'Temperatura elevada',  msg:`${nombre}: ${valor}${unidad} supera umbral máximo` };
    else if (valor < (u.tmin  || 10)) alerta = { tipo:'wa', titulo:'Temperatura muy baja', msg:`${nombre}: ${valor}${unidad} bajo umbral mínimo` };
  } else if (tipo === 'Humedad') {
    if      (valor > (u.hcrit || 90)) alerta = { tipo:'cr', titulo:'Humedad crítica', msg:`${nombre}: ${valor}${unidad}` };
    else if (valor > (u.hmax  || 80)) alerta = { tipo:'wa', titulo:'Humedad alta',    msg:`${nombre}: ${valor}${unidad}` };
  } else if (tipo === 'CO2') {
    if      (valor > (u.co2cr || 2000)) alerta = { tipo:'cr', titulo:'CO2 peligroso', msg:`${nombre}: ${valor} ppm` };
    else if (valor > (u.co2wa || 1000)) alerta = { tipo:'wa', titulo:'CO2 elevado',   msg:`${nombre}: ${valor} ppm` };
  }
  if (alerta) {
    await dbPush('alertas', {
      ...alerta,
      sensorId,
      icono: tipo === 'Temperatura' ? 'ri-temp-hot-line' : 'ri-alert-line',
      ts: Date.now(),
    });
  }
}

// ════════════════════════════════════════════
//  CHECK OFFLINE — cada 30 segundos
// ════════════════════════════════════════════
setInterval(async () => {
  const sensores = await dbGet('sensores') || {};
  const ahora    = Date.now();
  for (const [id, s] of Object.entries(sensores)) {
    if (s.estado === 'online' && (ahora - (s.ultimaLectura || 0)) > 35000) {
      await dbUpdate(`sensores/${id}`, { estado: 'offline' });
      await dbPush('alertas', {
        tipo: 'wa', titulo: 'Sensor desconectado',
        msg:  `${s.nombre} sin datos por más de 30s`,
        sensorId: id, icono: 'ri-wifi-off-line', ts: ahora,
      });
      console.log(`[OFFLINE] ${s.nombre}`);
    }
  }
}, 30000);

// ════════════════════════════════════════════
//  UDP — Escuchar anuncios de ESP32
// ════════════════════════════════════════════
const udp = dgram.createSocket('udp4');
udp.on('message', async (msg, rinfo) => {
  try {
    const data = JSON.parse(msg.toString());
    if (data.evento !== 'sv-iot-announce' || !data.mac) return;
    const sensorId = 'esp_' + data.mac.replace(/[:.]/g, '').toLowerCase();
    const existing = await dbGet(`sensores/${sensorId}`);
    if (!existing) {
      await dbSet(`sensores/${sensorId}`, {
        id: sensorId, mac: data.mac,
        nombre: data.nombre || sensorId,
        tipo:   data.tipo   || 'Desconocido',
        ip: rinfo.address, valor: null, unidad: '',
        sector: '', registrado: false, estado: 'online',
        ultimaLectura: Date.now(), creadoEn: Date.now(),
      });
      console.log(`[UDP] Nuevo sensor detectado: ${data.nombre} (${rinfo.address})`);
    }
  } catch (e) {}
});
udp.bind(5050, () => {
  udp.setBroadcast(true);
  console.log('✓ UDP Discovery en puerto 5050');
});

// ════════════════════════════════════════════
//  START
// ════════════════════════════════════════════
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║  Backend IoT corriendo en :${PORT}      ║`);
  console.log(`║  http://localhost:${PORT}               ║`);
  console.log(`╚══════════════════════════════════════╝\n`);
});
