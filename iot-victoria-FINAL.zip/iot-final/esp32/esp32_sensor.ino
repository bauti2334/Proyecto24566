/**
 * ╔══════════════════════════════════════════════╗
 * ║   SOLUCIONES VICTORIA — Firmware ESP32       ║
 * ║   v1.0  |  IoT Sensor Node                  ║
 * ╚══════════════════════════════════════════════╝
 *
 * Librerías necesarias (instalar en Arduino IDE / PlatformIO):
 *   - WiFi.h             (incluida en ESP32 core)
 *   - ESPmDNS.h          (incluida en ESP32 core)
 *   - WebServer.h        (incluida en ESP32 core)
 *   - HTTPClient.h       (incluida en ESP32 core)
 *   - ArduinoJson        (instalar: Benoit Blanchon, v6.x)
 *   - DHT sensor library (instalar: Adafruit, opcional si usás DHT)
 *   - Adafruit Unified Sensor (dependencia de DHT)
 *
 * HARDWARE SOPORTADO:
 *   - Temperatura/Humedad: DHT11, DHT22, SHT30 (I2C)
 *   - Presión: BMP280, BME280
 *   - CO2: MH-Z19, SCD30
 *   - Luz: BH1750, LDR analógico
 *   - Cualquier sensor con salida analógica/digital
 *
 * ─────────────────────────────────────────────
 *  CONFIGURACIÓN — EDITÁ ESTA SECCIÓN
 * ─────────────────────────────────────────────
 */

// ── WiFi ──────────────────────────────────────
#define WIFI_SSID       "TuRedWiFi"
#define WIFI_PASSWORD   "TuContraseña"

// ── Identificación del dispositivo ────────────
// Nombre único para mDNS: aparecerá como sensor-01.local
#define DEVICE_NAME     "sensor-01"
#define DEVICE_TYPE     "Temperatura"   // Temperatura | Humedad | CO2 | Presión | Luz
#define SECTOR_ID       ""              // Se asigna desde el dashboard (dejar vacío)

// ── Backend API ───────────────────────────────
// IP o dominio de tu servidor Node.js
#define API_URL         "http://192.168.1.100:3000"
#define API_TOKEN       "sv-iot-token-2024"   // Token simple de seguridad

// ── Intervalos (milisegundos) ─────────────────
#define INTERVAL_SEND     10000   // Enviar datos cada 10 segundos
#define INTERVAL_ANNOUNCE  5000   // Anunciarse por broadcast UDP cada 5s

// ── Pines de sensores (ajustar según tu hardware) ──
#define PIN_DHT         4     // GPIO4 → DHT11/DHT22
#define DHT_TYPE        DHT22
#define PIN_CO2_RX      16    // GPIO16 → MH-Z19 TX
#define PIN_CO2_TX      17    // GPIO17 → MH-Z19 RX
#define PIN_LDR         34    // GPIO34 → LDR (analógico)
#define PIN_LED_STATUS  2     // LED integrado (GPIO2)

// ─────────────────────────────────────────────
//  LIBRERÍAS
// ─────────────────────────────────────────────
#include <WiFi.h>
#include <ESPmDNS.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <WiFiUdp.h>
#include <ArduinoJson.h>

// Descomenta el sensor que uses:
// #include <DHT.h>
// #include <Wire.h>
// #include <Adafruit_BME280.h>
// #include <MHZ19.h>

// ─────────────────────────────────────────────
//  VARIABLES GLOBALES
// ─────────────────────────────────────────────
WebServer server(80);
WiFiUDP udp;

// DHT dht(PIN_DHT, DHT_TYPE);  // ← descomentar si usás DHT

unsigned long lastSend     = 0;
unsigned long lastAnnounce = 0;
String deviceMAC           = "";
float  sensorValue         = 0.0;
String sensorUnit          = "°C";
String deviceStatus        = "online";

// ─────────────────────────────────────────────
//  SETUP
// ─────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("\n╔══════════════════════════════╗");
  Serial.println("║  Soluciones Victoria IoT     ║");
  Serial.println("╚══════════════════════════════╝");

  pinMode(PIN_LED_STATUS, OUTPUT);
  digitalWrite(PIN_LED_STATUS, LOW);

  // ── Inicializar sensor ──
  initSensor();

  // ── Conectar WiFi ──
  connectWiFi();

  // ── Guardar MAC como ID único ──
  deviceMAC = WiFi.macAddress();
  deviceMAC.replace(":", "");
  Serial.println("MAC/ID: " + deviceMAC);

  // ── mDNS ──
  if (MDNS.begin(DEVICE_NAME)) {
    MDNS.addService("http",  "tcp", 80);
    MDNS.addService("sv-iot","udp", 5050);
    Serial.println("mDNS: " + String(DEVICE_NAME) + ".local");
  }

  // ── UDP para discovery ──
  udp.begin(5050);

  // ── Rutas HTTP locales ──
  server.on("/",       handleRoot);
  server.on("/datos",  handleDatos);
  server.on("/info",   handleInfo);
  server.on("/ping",   handlePing);
  server.begin();

  Serial.println("IP: " + WiFi.localIP().toString());
  Serial.println("Listo ✓\n");
  digitalWrite(PIN_LED_STATUS, HIGH);
}

// ─────────────────────────────────────────────
//  LOOP
// ─────────────────────────────────────────────
void loop() {
  server.handleClient();
  handleUDPDiscovery();

  unsigned long now = millis();

  if (now - lastSend > INTERVAL_SEND) {
    lastSend = now;
    readSensor();
    sendToAPI();
  }

  if (now - lastAnnounce > INTERVAL_ANNOUNCE) {
    lastAnnounce = now;
    broadcastAnnouncement();
  }

  delay(10);
}

// ─────────────────────────────────────────────
//  WIFI
// ─────────────────────────────────────────────
void connectWiFi() {
  Serial.print("Conectando a WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500);
    Serial.print(".");
    attempts++;
    // Parpadear LED mientras conecta
    digitalWrite(PIN_LED_STATUS, !digitalRead(PIN_LED_STATUS));
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✓ WiFi conectado: " + WiFi.localIP().toString());
    digitalWrite(PIN_LED_STATUS, HIGH);
  } else {
    Serial.println("\n✗ Error WiFi — reiniciando en 5s");
    delay(5000);
    ESP.restart();
  }
}

// ─────────────────────────────────────────────
//  SENSOR
// ─────────────────────────────────────────────
void initSensor() {
  // ── Descomentar según tu sensor ──

  // DHT:
  // dht.begin();

  // BME280 (I2C):
  // Wire.begin();
  // bme.begin(0x76);

  Serial.println("Sensor iniciado: " + String(DEVICE_TYPE));
}

void readSensor() {
  String type = String(DEVICE_TYPE);

  if (type == "Temperatura") {
    // Con DHT:
    // sensorValue = dht.readTemperature();
    // if (isnan(sensorValue)) sensorValue = 22.0;

    // SIMULACIÓN (reemplazar con lectura real):
    sensorValue = 22.0 + (random(-30, 30) / 10.0);
    sensorUnit  = "°C";

  } else if (type == "Humedad") {
    // Con DHT:
    // sensorValue = dht.readHumidity();
    sensorValue = 55.0 + (random(-100, 100) / 10.0);
    sensorUnit  = "%";

  } else if (type == "CO2") {
    // Con MH-Z19:
    // sensorValue = mhz19.getCO2();
    sensorValue = 400 + random(0, 600);
    sensorUnit  = "ppm";

  } else if (type == "Presión") {
    // Con BME280:
    // sensorValue = bme.readPressure() / 100.0F;
    sensorValue = 1013.0 + (random(-30, 30) / 10.0);
    sensorUnit  = "hPa";

  } else if (type == "Luz") {
    // Analógico:
    // int raw = analogRead(PIN_LDR);
    // sensorValue = map(raw, 0, 4095, 0, 10000);
    sensorValue = random(1000, 8000);
    sensorUnit  = "lux";
  }

  Serial.printf("[%s] Lectura: %.1f %s\n", DEVICE_TYPE, sensorValue, sensorUnit.c_str());
}

// ─────────────────────────────────────────────
//  ENVIAR DATOS A API
// ─────────────────────────────────────────────
void sendToAPI() {
  if (WiFi.status() != WL_CONNECTED) { connectWiFi(); return; }

  HTTPClient http;
  http.begin(String(API_URL) + "/api/sensores/datos");
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer " + String(API_TOKEN));

  StaticJsonDocument<256> doc;
  doc["mac"]    = deviceMAC;
  doc["nombre"] = DEVICE_NAME;
  doc["tipo"]   = DEVICE_TYPE;
  doc["valor"]  = sensorValue;
  doc["unidad"] = sensorUnit;
  doc["ip"]     = WiFi.localIP().toString();
  doc["rssi"]   = WiFi.RSSI();
  doc["sector"] = SECTOR_ID;

  String body;
  serializeJson(doc, body);

  int code = http.POST(body);
  if (code == 200 || code == 201) {
    Serial.println("✓ API OK (" + String(code) + ")");
    // Parpadeo rápido = dato enviado
    for (int i = 0; i < 2; i++) {
      digitalWrite(PIN_LED_STATUS, LOW); delay(50);
      digitalWrite(PIN_LED_STATUS, HIGH); delay(50);
    }
  } else {
    Serial.println("✗ API Error: " + String(code));
  }
  http.end();
}

// ─────────────────────────────────────────────
//  UDP BROADCAST — Discovery
// ─────────────────────────────────────────────
void broadcastAnnouncement() {
  StaticJsonDocument<200> doc;
  doc["evento"]  = "sv-iot-announce";
  doc["mac"]     = deviceMAC;
  doc["nombre"]  = DEVICE_NAME;
  doc["tipo"]    = DEVICE_TYPE;
  doc["ip"]      = WiFi.localIP().toString();
  doc["mdns"]    = String(DEVICE_NAME) + ".local";

  String msg;
  serializeJson(doc, msg);

  udp.beginPacket("255.255.255.255", 5050);
  udp.print(msg);
  udp.endPacket();
}

void handleUDPDiscovery() {
  int sz = udp.parsePacket();
  if (sz <= 0) return;

  char buf[256] = {0};
  udp.read(buf, sizeof(buf)-1);
  String incoming = String(buf);

  // Responder a scan del frontend
  if (incoming.contains("sv-iot-scan")) {
    StaticJsonDocument<200> resp;
    resp["evento"]  = "sv-iot-response";
    resp["mac"]     = deviceMAC;
    resp["nombre"]  = DEVICE_NAME;
    resp["tipo"]    = DEVICE_TYPE;
    resp["ip"]      = WiFi.localIP().toString();
    resp["valor"]   = sensorValue;
    resp["unidad"]  = sensorUnit;

    String msg;
    serializeJson(resp, msg);

    udp.beginPacket(udp.remoteIP(), udp.remotePort());
    udp.print(msg);
    udp.endPacket();
  }
}

// ─────────────────────────────────────────────
//  RUTAS HTTP LOCALES
// ─────────────────────────────────────────────
void setCORS() {
  server.sendHeader("Access-Control-Allow-Origin",  "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Authorization,Content-Type");
}

void handleRoot() {
  setCORS();
  String html = "<html><body style='font-family:monospace;padding:20px'>"
    "<h2>🌡 Soluciones Victoria — " + String(DEVICE_NAME) + "</h2>"
    "<p><b>Tipo:</b> " + String(DEVICE_TYPE) + "</p>"
    "<p><b>Valor:</b> " + String(sensorValue, 1) + " " + sensorUnit + "</p>"
    "<p><b>IP:</b> " + WiFi.localIP().toString() + "</p>"
    "<p><b>MAC:</b> " + deviceMAC + "</p>"
    "<p><a href='/datos'>Ver JSON →</a></p>"
    "</body></html>";
  server.send(200, "text/html", html);
}

void handleDatos() {
  readSensor();
  setCORS();
  StaticJsonDocument<256> doc;
  doc["mac"]    = deviceMAC;
  doc["nombre"] = DEVICE_NAME;
  doc["tipo"]   = DEVICE_TYPE;
  doc["valor"]  = sensorValue;
  doc["unidad"] = sensorUnit;
  doc["ip"]     = WiFi.localIP().toString();
  doc["rssi"]   = WiFi.RSSI();
  doc["uptime"] = millis() / 1000;
  String out;
  serializeJson(doc, out);
  server.send(200, "application/json", out);
}

void handleInfo() {
  setCORS();
  StaticJsonDocument<256> doc;
  doc["nombre"]    = DEVICE_NAME;
  doc["tipo"]      = DEVICE_TYPE;
  doc["mac"]       = deviceMAC;
  doc["ip"]        = WiFi.localIP().toString();
  doc["firmware"]  = "1.0.0";
  doc["mdns"]      = String(DEVICE_NAME) + ".local";
  String out;
  serializeJson(doc, out);
  server.send(200, "application/json", out);
}

void handlePing() {
  setCORS();
  server.send(200, "application/json", "{\"status\":\"ok\",\"device\":\"" + String(DEVICE_NAME) + "\"}");
}
